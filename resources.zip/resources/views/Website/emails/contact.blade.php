<h1>New contact submission</h1>

<ul>
    <li><strong>Name:</strong> {{ $data['name'] }}</li>
    <li><strong>Email:</strong> {{ $data['email'] }}</li>
    <li><strong>Phone:</strong> {{ $data['phone'] }}</li>
    <li><strong>Age:</strong> {{ $data['age'] }}</li>
    <li><strong>Gender:</strong> {{ $data['gender'] }}</li>
    <li><strong>Education:</strong> {{ $data['education'] }}</li>
    <li><strong>Message:</strong> {{ $data['message'] }}</li>
</ul>
